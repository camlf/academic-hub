from ocs_academic_hub import OMFClient
import pandas as pd
import numpy as np
from datetime import datetime, timedelta
from dateutil.parser import parse
import time
from time import sleep

# Data frame generation
start = pd.to_datetime('2021-04-01 13:17:00')
end = pd.to_datetime('2021-04-01 13:20:00')
freq = 1 #Hz
column = 4
batch_size = 10

time_range = pd.date_range(start, end, freq=f'{1/freq*1000000000}ns')

np.random.seed(seed=1111)
data = np.random.uniform(1, high=100, size=(len(time_range), column))

df = pd.DataFrame({'Timestamp': time_range})
#df = df.set_index('Timestamp')
i = 0
while i < column:
    df[f'col{i + 1}'] = data[:,i]
    i += 1
print(df)

# Schedular
from threading import Timer

class RepeatedTimer(object):
    def __init__(self, interval, function, *args, **kwargs):
        self._timer     = None
        self.interval   = interval
        self.function   = function
        self.args       = args
        self.kwargs     = kwargs
        self.is_running = False
        self.start()

    def _run(self):
        self.is_running = False
        self.start()
        self.function(*self.args, **self.kwargs)

    def start(self):
        if not self.is_running:
            self._timer = Timer(self.interval, self._run)
            self._timer.start()
            self.is_running = True

    def stop(self):
        self._timer.cancel()
        self.is_running = False

# Batching OMF messages to send to EDS
class Batch:
    def __init__(self):
        self._batch = pd.DataFrame(columns=df.columns)

    # function to get value of _batch
    def get_batch(self):
        # print("getter method called")
        return self._batch

    # function to set value of _batch
    def set_batch(self, a):
        # print("setter method called")
        if len(self._batch) < batch_size:
            self._batch = a
            #print(f'added to batch {self._batch}')
        elif len(self._batch) >= batch_size:
            t = time.time()
            omf_client.update_tags(self._batch, asset)
            #print(f'sent the batch {self._batch}')
            self._batch = pd.DataFrame(columns=df.columns)
            print(f'elapsed {time.time() - t}')
            # print(f'reset {self._batch}')

    # function to delete _batch attribute
    def del_batch(self):
        del self._batch

    batch = property(get_batch, set_batch, del_batch)


asset = 'test'
omf_client = OMFClient()
batch_df = Batch()

interval = 1 / freq

def update_batch(df_batch, df_rt, asset):
    batch_df.batch = df_batch.append(df_rt)


def event():
    df_rt = df[abs(df['Timestamp'] - pd.Timestamp.now()) <= timedelta(seconds=interval)]
    update_batch(batch_df.batch, df_rt, asset)


if pd.Timestamp.now() > start:
    print("starting...")
    rt = RepeatedTimer(1 / freq, event)  # it auto-starts, no need of rt.start()
    try:
        sleep((end - pd.Timestamp.now()).total_seconds())  # your long-running job goes here...
    finally:
        rt.stop()  # better in a try/finally block to make sure the program ends!
        print("stopped!!!")