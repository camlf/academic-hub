from ocs_academic_hub import OMFClient
import pandas as pd
import numpy as np
from datetime import datetime, timedelta
from dateutil.parser import parse

# Data frame generation
start = pd.to_datetime('2021-03-29 17:05:00')
end = pd.to_datetime('2021-03-29 17:10:00')
freq = 200 #Hz
column = 4

time_range = pd.date_range(start, end, freq=f'{1/freq*1000000000}ns')

np.random.seed(seed=1111)
data = np.random.uniform(1, high=100, size=(len(time_range), column))

df = pd.DataFrame({'Timestamp': time_range})
#df = df.set_index('Timestamp')
i = 0
while i < column:
    df[f'col{i + 1}'] = data[:,i]
    i += 1
print(df)

# Schedular
from threading import Timer

class RepeatedTimer(object):
    def __init__(self, interval, function, *args, **kwargs):
        self._timer     = None
        self.interval   = interval
        self.function   = function
        self.args       = args
        self.kwargs     = kwargs
        self.is_running = False
        self.start()

    def _run(self):
        self.is_running = False
        self.start()
        self.function(*self.args, **self.kwargs)

    def start(self):
        if not self.is_running:
            self._timer = Timer(self.interval, self._run)
            self._timer.start()
            self.is_running = True

    def stop(self):
        self._timer.cancel()
        self.is_running = False


from time import sleep

asset = 'test'
omf_client = OMFClient()


def event():
    df_rt = df[abs(df['Timestamp'] - pd.Timestamp.now()) <= timedelta(seconds=1 / freq)]
    omf_client.update_tags(df_rt, asset)
    # print(df_rt)


if pd.Timestamp.now() > start:
   print("starting...")
   rt = RepeatedTimer(1 / freq, event)  # it auto-starts, no need of rt.start()
   try:
       sleep((end - pd.Timestamp.now()).total_seconds())  # your long-running job goes here...
   finally:
       rt.stop()  # better in a try/finally block to make sure the program ends!
       print("stopped!!!")